# Studio Dilshod — GitHub Pages uchun portfolio

## Ko‘rish

ZIP faylni to‘liq alohida papkaga chiqaring va o‘sha papkadagi `index.html` faylini brauzerda ishga tushiring. Portfoliodan beshta mahalliy demo va internetdagi mavjud barbershop demosiga o‘tiladi.

| Papka | Chex tilidagi demo |
| --- | --- |
| `restaurant-cafe/` | Sůl & Oliva — restoran va kafe |
| `beauty-salon/` | Ateliér Míza — go‘zallik saloni |
| `auto-service/` | Garáž Sever — avtoservis |
| `construction-handyman/` | Dům & Dílna — ta’mirlash va montaj |
| `cleaning-service/` | Jasno — tozalash xizmati |

## GitHub Pages’da joylashtirish

1. Yangi GitHub repozitori yarating.
2. ZIP ichidagi fayl va papkalarni repozitori ildiziga yuklang. `index.html`, `.nojekyll`, `assets/` va beshta demo papkasi bir darajada turishi kerak.
3. GitHub’da **Settings → Pages** bo‘limini oching. **Deploy from a branch → main → /(root)** ni tanlang va **Save** tugmasini bosing.
4. Nashr tugagach **Visit site** orqali portfolioni oching. Demolar portfolio bilan bir repozitorida alohida URL manzillarida ochiladi.

[GitHub Pages rasmiy qo‘llanmasi](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)

## Tahrirlash

Sahifalar oddiy HTML, CSS va JavaScript’dan iborat. Matnlar tegishli `index.html` fayllarida, uslublar har bir sahifa yonidagi `style.css` faylida joylashgan. Rasm va shriftlar paketga kiritilgan. Alohida demo repozitoriga ko‘chirilsa, umumiy `assets/` papkasini ham ko‘chiring va HTML va CSS’dagi nisbiy yo‘llarni moslang.

Demo bizneslari xayoliy. Formada brauzer maydonlarni tekshiradi va sinov natijasini ko‘rsatadi. Ma’lumotlar yuborilmaydi yoki saqlanmaydi. Portfolio kontakt tugmasi uchun GitHub profili ishlatilgan. Barbershop kartasi mavjud tashqi saytga yo‘naltiradi.

## Media

Rasmlar Unsplash’dan olingan. `PHOTO-SOURCES.md` faylida rasm manbalari keltirilgan. Shriftlarning OFL litsenziyalari `assets/` papkasida.
