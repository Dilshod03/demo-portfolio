document.body.classList.add('js');
const nav = document.querySelector('#nav');
const toggle = document.querySelector('.nav-toggle');
function showMenu(open) {
  nav.classList.toggle('open', open);
  toggle.setAttribute('aria-expanded', String(open));
}
toggle.addEventListener('click', () => showMenu(toggle.getAttribute('aria-expanded') === 'false'));
nav.addEventListener('click', event => {
  if (event.target.closest('a')) showMenu(false);
});
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
    showMenu(false);
    toggle.focus();
  }
});

const form = document.querySelector('[data-demo]');
if (form) {
  form.querySelector('[type=submit]').disabled = false;
  const service = form.elements.service;
  const date = form.elements.date;
  const today = new Date();
  date.min = [
    today.getFullYear(),
    String(today.getMonth() + 1).padStart(2, '0'),
    String(today.getDate()).padStart(2, '0')
  ].join('-');

  document.querySelectorAll('.select-service').forEach(button => {
    button.addEventListener('click', () => {
      if (!document.body.classList.contains('olive')) service.value = button.dataset.service;
      location.hash = 'kontakt';
      form.elements.name.focus({ preventScroll:true });
    });
  });
  form.addEventListener('submit', event => {
    event.preventDefault();
    const feedback = form.querySelector('.feedback');
    feedback.hidden = false;
    feedback.textContent = 'Formulář je vyplněný správně. Jde o ukázku, takže údaje nebyly odeslány.';
  });
  form.addEventListener('input', () => {
    const feedback = form.querySelector('.feedback');
    feedback.hidden = true;
    feedback.textContent = '';
  });
}

